//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


// Airport checkin system

let tickets: [String:String] = ["Peter":"123456", "George":"234567", "Michael":"345678", "Tony":"456789"]

var availableTicketsForFlight123972: [String:Bool] = ["123456":true, "234567":true, "345678":true, "456789":true, "567890":true]


func findTicketNumberFor(person: String) -> String {
    for aTicket in tickets {
        if aTicket.key == person{
            return aTicket.value
        }
    }
    return ""
}

func findPersonNameFor(ticket: String) -> String {
    for aTicket in tickets {
        if aTicket.value == ticket {
            return aTicket.key
        }
    }
    return ""
}

func checkInPassenderWith(ticket: String){
    for aTicket in availableTicketsForFlight123972 {
        if aTicket.key == ticket {
            availableTicketsForFlight123972[aTicket.key] = false
        }
    }
}


func printFlightPassengerInformation(){
    var notTakenTicketsCount = 0
    
    for aTicket in availableTicketsForFlight123972 {
        if aTicket.value == true {
            notTakenTicketsCount += 1
        }
        else {
            let personName = findPersonNameFor(ticket: aTicket.key)
            print(personName)
        }
    }
}

//let ticket = findTicketNumberFor(person: "Michael")
//checkInPassenderWith(ticket: ticket)
//checkInPassenderWith(ticket: findTicketNumberFor(person: "George"))
//
//
//printFlightPassengerInformation()
//print(availableTicketsForFlight123972)


struct Ticket {
    var ticketHolderName: String
    var number: String
    var taken: Bool
}


var ticket1 = Ticket(ticketHolderName: "Peter", number: "12345", taken: false)
var ticket2 = Ticket(ticketHolderName: "George", number: "234567", taken: false)
var ticket3 = Ticket(ticketHolderName: "Michael", number: "334567", taken: false)


var airportTickets: [Ticket] = [ticket1, ticket2, ticket3]

func serachForTicketBy(name: String) -> Ticket?{
    for aTicket in airportTickets {
        if aTicket.ticketHolderName == name {
            return aTicket
        }
    }
    
    return nil
}

func serachForTicketBy(number: String) -> Ticket?{
    for aTicket in airportTickets {
        if aTicket.number == number {
            return aTicket
        }
    }
    
    return nil
}

func checkIn(ticket: Ticket) -> Ticket {
    var ticket = ticket
    ticket.taken = true
    return ticket
}

airportTickets[1] = checkIn(ticket: airportTickets[1])
airportTickets[2] = checkIn(ticket: airportTickets[2])


func printInformationForAirportTickets() {
    var notTaken = 0
    for aTicket in airportTickets {
        if aTicket.taken == true {
            print(aTicket.ticketHolderName)
        }
        else {
            notTaken += 1
        }
    }
    print("Tickets not taken count:", notTaken)
}

//printInformationForAirportTickets()



var fuelLog: [(date: String, distance: Float, amount: Float)] = []


func fuelConsumptionFor(distance: Float, consumedFuel: Float) -> Float {
    return consumedFuel * 100 / distance
}

func addToLog(dateOfFueling: String, distance: Float, amount: Float) {
    fuelLog.append((date: dateOfFueling, distance: distance, amount: amount))
    print(fuelConsumptionFor(distance: distance, consumedFuel: amount))
}

//addToLog(dateOfFueling: "2017-06-26", distance: 180, amount: 12)
//addToLog(dateOfFueling: "2017-06-22", distance: 150, amount: 9)


func mpg(lp100k: Float) -> Float {
    // 1 mile = 1.60934
    // 1 gallon = 3.78541
    // 1 l / 100k = (1 / 3.78541) / (100 / 1.60934)
    let mpg = (100 * 3.78541) / (lp100k * 1.60934)
    return mpg
}

//print(mpg(lp100k: 10))

let price: Float = 2.10

func averagePriceForKm() -> Float{
    var allConsumption: Float = 0
    var allDistance: Float = 0
    
    for anItem in fuelLog {
        allConsumption += anItem.amount
        allDistance += anItem.distance
    }
    
    let average = fuelConsumptionFor(distance: allDistance, consumedFuel: allConsumption)
    let lp1km = average/100
    let pricePer1KM = lp1km * price
    return pricePer1KM
}

//print("Price per 1 km :", averagePriceForKm())

func printLogInformation() {
    for anItem in fuelLog {
        print("Date of fueling: \(anItem.date) consumption: \(fuelConsumptionFor(distance: anItem.distance, consumedFuel: anItem.amount))")
    }
}

//printLogInformation()






/// L3


let string = "aasdfASDFoqwepmqnASDwlkanwdADs"
var dict = [Character:Int]()
func checkAndIncrease(for char:Character)
{
    if let repeating = dict[char]
    {
        dict[char] = repeating + 1
    }
    else
    {
        dict[char] = 1
    }
}

for char in string.characters
{
    switch char
    {
    case "a":
        checkAndIncrease(for:"a")
    case "o":
        checkAndIncrease(for: "o")
    case "e":
        checkAndIncrease(for: "e")
    case "u":
        checkAndIncrease(for: "u")
    case "i":
        checkAndIncrease(for: "i")
    default:
        checkAndIncrease(for: "`")
    }
}

// Belote


let teamA = "78AKQJJAT9788"
let teamB = "77JJKQTT9"

func calculatePointsFor(teamCards: String) -> Int{
    var sum = 0
    for aCard in teamCards.characters
    {
        switch aCard {
        case "7","8":
            sum += 0
        case "9":
            sum += 14
        case "T":
            sum += 10
        case "Q":
            sum += 3
        case "K":
            sum += 4
        case "J":
            sum += 20
        case "A":
            sum += 11
        default :
            break
        }
    }
    return sum
}


//print(calculatePointsFor(teamCards: teamA))


//enum Planet{
//    case Mercury
//    case Venus
//    case Earth
//    case Mars
//    case Jupiter
//    case Saturn
//    case Uranus
//    case Neptune
//}
//
//
//
//func distanceFromSunFor(planet: Planet) -> Float { // distance units = AU
//    
//    switch planet {
//    case .Mercury:
//        return 0.4
//    case .Venus:
//        return 0.7
//    case .Earth:
//        return 1.0
//    case .Mars:
//        return 1.5
//    case .Jupiter:
//        return 5.2
//    case .Saturn:
//        return 9.5
//    case .Uranus:
//        return 19.2
//    case .Neptune:
//        return 30.1
//    }
//}
//
//
//
//print(distanceFromSunFor(planet: .Uranus))



// name : 14Z187
enum iPhoneModels: String {
    case iPhone6 = "11z87"
    case iPhone6Plus = "11z99"
    case iPhone6S = "12z80"
    case iPhone6SPlus = "12z90"
    case iPhone7 = "13z80"
    case iPhone7Plus = "13z92"
}

func getiPhoneModel(manufacturingModelString: String) -> String{
    let model = iPhoneModels(rawValue: manufacturingModelString)
    if model == nil {
        return "Model not found"
    }
    
    switch model! {
    case .iPhone6:
        return "6"
    case .iPhone6Plus:
        return "6+"
    case .iPhone6S:
        return "6S"
    case .iPhone6SPlus:
        return "6S+"
    case .iPhone7:
        return "7"
    case .iPhone7Plus:
        return "7+"
    }
    
}

//let myIphoneManufacturingModelString = "12z90"
//let myIphoneModelString = getiPhoneModel(manufacturingModelString: myIphoneManufacturingModelString)

//print("I Have iPhone \(myIphoneModelString)")


// A game


enum GameMode{
    case easy
    case pro
}

enum Actions{
    case move // easy / pro = 1
    case attack // easy = 5, pro = 10
    case defend // easy = 8, pro = 12
    case skip // easy = 1, pro = 0
    case `return` // easy = 5, pro = 2
}


let gameMode: GameMode = .pro
let sequenceOfActions: [Actions] = [.move, .defend, .attack, .attack, .skip]

func pointsFromGame(mode: GameMode, actions: [Actions]) -> Int{
    var points = 0
    
    for action in actions {
        let tupple = (mode, action)
        switch tupple {
        case (_, .move):
            points += 1
        case (.easy, .attack):
            points += 5
        case (.pro, .attack):
            points += 10
        case (.easy, .defend):
            points += 8
        case (.pro, .defend):
            points += 12
        default:
            break
        }
    }
    
    return points
}

print(pointsFromGame(mode: gameMode, actions: sequenceOfActions))
















