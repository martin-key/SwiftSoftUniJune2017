//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


// Airport checkin system

let tickets: [String:String] = ["Peter":"123456", "George":"234567", "Michael":"345678", "Tony":"456789"]

var availableTicketsForFlight123972: [String:Bool] = ["123456":true, "234567":true, "345678":true, "456789":true, "567890":true]


func findTicketNumberFor(person: String) -> String {
    for aTicket in tickets {
        if aTicket.key == person{
            return aTicket.value
        }
    }
    return ""
}

func findPersonNameFor(ticket: String) -> String {
    for aTicket in tickets {
        if aTicket.value == ticket {
            return aTicket.key
        }
    }
    return ""
}

func checkInPassenderWith(ticket: String){
    for aTicket in availableTicketsForFlight123972 {
        if aTicket.key == ticket {
            availableTicketsForFlight123972[aTicket.key] = false
        }
    }
}


func printFlightPassengerInformation(){
    var notTakenTicketsCount = 0
    
    for aTicket in availableTicketsForFlight123972 {
        if aTicket.value == true {
            notTakenTicketsCount += 1
        }
        else {
            let personName = findPersonNameFor(ticket: aTicket.key)
            print(personName)
        }
    }
}

//let ticket = findTicketNumberFor(person: "Michael")
//checkInPassenderWith(ticket: ticket)
//checkInPassenderWith(ticket: findTicketNumberFor(person: "George"))
//
//
//printFlightPassengerInformation()
//print(availableTicketsForFlight123972)


struct Ticket {
    var ticketHolderName: String
    var number: String
    var taken: Bool
}


var ticket1 = Ticket(ticketHolderName: "Peter", number: "12345", taken: false)
var ticket2 = Ticket(ticketHolderName: "George", number: "234567", taken: false)
var ticket3 = Ticket(ticketHolderName: "Michael", number: "334567", taken: false)


var airportTickets: [Ticket] = [ticket1, ticket2, ticket3]

func serachForTicketBy(name: String) -> Ticket?{
    for aTicket in airportTickets {
        if aTicket.ticketHolderName == name {
            return aTicket
        }
    }
    
    return nil
}

func serachForTicketBy(number: String) -> Ticket?{
    for aTicket in airportTickets {
        if aTicket.number == number {
            return aTicket
        }
    }
    
    return nil
}

func checkIn(ticket: Ticket) -> Ticket {
    var ticket = ticket
    ticket.taken = true
    return ticket
}

airportTickets[1] = checkIn(ticket: airportTickets[1])
airportTickets[2] = checkIn(ticket: airportTickets[2])


func printInformationForAirportTickets() {
    var notTaken = 0
    for aTicket in airportTickets {
        if aTicket.taken == true {
            print(aTicket.ticketHolderName)
        }
        else {
            notTaken += 1
        }
    }
    print("Tickets not taken count:", notTaken)
}

//printInformationForAirportTickets()



var fuelLog: [(date: String, distance: Float, amount: Float)] = []


func fuelConsumptionFor(distance: Float, consumedFuel: Float) -> Float {
    return consumedFuel * 100 / distance
}

func addToLog(dateOfFueling: String, distance: Float, amount: Float) {
    fuelLog.append((date: dateOfFueling, distance: distance, amount: amount))
    print(fuelConsumptionFor(distance: distance, consumedFuel: amount))
}

addToLog(dateOfFueling: "2017-06-26", distance: 180, amount: 12)
addToLog(dateOfFueling: "2017-06-22", distance: 150, amount: 9)


func mpg(lp100k: Float) -> Float {
    // 1 mile = 1.60934
    // 1 gallon = 3.78541
    // 1 l / 100k = (1 / 3.78541) / (100 / 1.60934)
    let mpg = (100 * 3.78541) / (lp100k * 1.60934)
    return mpg
}

print(mpg(lp100k: 10))

let price: Float = 2.10

func averagePriceForKm() -> Float{
    var allConsumption: Float = 0
    var allDistance: Float = 0
    
    for anItem in fuelLog {
        allConsumption += anItem.amount
        allDistance += anItem.distance
    }
    
    let average = fuelConsumptionFor(distance: allDistance, consumedFuel: allConsumption)
    let lp1km = average/100
    let pricePer1KM = lp1km * price
    return pricePer1KM
}

print("Price per 1 km :", averagePriceForKm())

func printLogInformation() {
    for anItem in fuelLog {
        print("Date of fueling: \(anItem.date) consumption: \(fuelConsumptionFor(distance: anItem.distance, consumedFuel: anItem.amount))")
    }
}

printLogInformation()

