//: Playground - noun: a place where people can play

import UIKit


// float myFunction(int arg1, int arg2, int arg3) .... 



func calculateAverageSpeed(trip: Float, duration: Float = 1.0) -> Float{
    let averageSpeed = trip/duration
    return averageSpeed
}

let avgSpeed1 = calculateAverageSpeed(trip: 320, duration: 4)
let avgSpeed2 = calculateAverageSpeed(trip: 70)

//print(avgSpeed1, avgSpeed2)



func convertToMPH(speedKPH: Double) -> Double {
    //1 mile = 1.60934 km
    let speedMPH = speedKPH/1.60934
    return speedMPH
}

//print(convertToMPH(speedKPH: 100))

func convertToMPS(speedKPH: Float) -> Float {
    // 1h = 60m * 60s = 3600s
    // 1km = 1000m
    // km/h = 1000m/3600s
    let speedMPS = (speedKPH * 1000) / 3600
    return speedMPS
}

//print(convertToMPS(speedKPH: 72.0))


20.distance(to: 12)
// (20.4).toMPH() 

extension Double{
    func toMPH() -> Double {
        let speedMPH = convertToMPH(speedKPH: self)
        return speedMPH
    }
}

//print("MPH:", 100.0.toMPH())





let myArray = [4,8,15,16,23,42]
let myDoubleArray = [4.0, 8.1, 15.92817236, 16.7, 23.234123, 42.0]
let myStringArray = ["Zhoro", "Moro", "Boro"]

var myOtherArray = [Int]()
let myOtherOtherArray: [Int] = Array<Int>()

myOtherArray.append(971)
myOtherArray.append(76)



var invitedGuests = ["Tom", "Janna", "Alex", "Martin"]
invitedGuests.append("Tom")
//print(invitedGuests)
//print(invitedGuests[2])
invitedGuests.append("Brian")
invitedGuests.count
invitedGuests.capacity
invitedGuests.remove(at: 3)
invitedGuests.index(of: "Tom")
invitedGuests.removeAll()
invitedGuests.isEmpty


var favoriteArtists: Set = ["Weeknd", "Rihanna", "Seether"]
favoriteArtists.insert("Jaya the cat")
favoriteArtists.insert("Seether")
//print(favoriteArtists)



var marks = [String:Double]()
marks["Georgi"] = 4.356
marks["Ivan"] = 5.784
marks["John"] = 3.866

let data: (arg1: Double, arg2: Double, arg3: String) = (4.234, 6.432, "Hello")

var places: [String:(lat:Double, lon:Double)] = ["Sofia":(42.7, 23.3),
                                                 "Vienna":(48.12, 16.22), "San Francisco":(37.47, -122.25)]
places["Sofia"]
places["Barcelona"] = (47.23, 2.11) // insert
places["Sofia"] = (42.7, 23.6) // modify
places["Sofia"]?.lat

// tupple

var matrix: [[Int]] = [[4, 12], [8, 6], [9, 862]]



let lotteryNumbers = [4,8,15,16,23,42]
for number in lotteryNumbers
{
//    print("Current number \(number)")
}

let animals:[String: Int] = ["Spider":8, "Fly":6, "Horse":4,
                             "Fiki":0]
for anAnimal in animals
{
//    print("\(anAnimal.key) has \(anAnimal.value) legs")
}

var currentHour = 9
while currentHour < 8
{
    currentHour += 1
}


let persons: [String: Bool] = ["Max":true, "Anne":true,
                               "Isdislav":false]
for person in persons
{
    if(person.value == true)
    {
//        print("\(person.key) please enter")
    }
    else
    {
//        print("\(person.key) go home")
    }
}

struct Fueling {
    var distance: Double
    var amount: Double
    var date: String
}

var fuelings1: [Fueling]
var fuelings: [(distance: Double, amount: Double, date: String)] = []

fuelings.append((distance: 240, amount: 17, date: "19.06.2017"))
fuelings.append((distance: 100, amount: 6, date: "20.06.2017"))

func getLp100k(distance: Double, amount: Double, date: String) -> Double {
    return 4
}

getLp100k(distance: fuelings[0].distance, amount: fuelings[0].amount, date: fuelings[0].date)


let myString: String? = nil

if let _ = myString {
    print(myString)
}


