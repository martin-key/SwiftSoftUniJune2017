//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



// Enum protocols, etc., fun stuff (;
protocol EnumProtocol {
    
}


enum MyEnum: Int, EnumProtocol {
    case one = 1
    case two = 2
}

enum MyOtherEnum: Int, EnumProtocol {
    case one1 = 1
    case two1 = 2
}

enum Events: String {
    case clickUrl = "https://phyreapp.com/api..........."
    case transitionToScreen = "https://phyreapp.com/api/......"
}

func logEvent(_ event: Events, event2: Events = .clickUrl){
    print(event.rawValue) // sending request to server
}

func checkProtocol(_ protocol1: EnumProtocol){
    print(protocol1)
    switch protocol1 {
    case is MyEnum:
        print("It is MyEnum")
    case is MyOtherEnum:
        print("It is MyOtherEnum")
    default:
        break
    }
}

func returnMemberFromProtocol() -> EnumProtocol{
    return MyOtherEnum.two1
}

checkProtocol(returnMemberFromProtocol())

//logEvent(.transitionToScreen)
//logEvent(.transitionToScreen, event2: .clickUrl)


let someInt = MyEnum.two.rawValue
let memberFromMyOtherEnum = MyOtherEnum(rawValue: someInt)


// Classes, Optionals

class MyClass{
    var anIntProperty: Float?
    
}

let myInstance = MyClass()

myInstance.anIntProperty = 3.14159286

if myInstance.anIntProperty != nil {
    let anotherNumber = myInstance.anIntProperty!
    print(anotherNumber)
}

if let anotherNumber = myInstance.anIntProperty {
    print(anotherNumber)
}







