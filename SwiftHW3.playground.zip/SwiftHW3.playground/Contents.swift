//: Playground - noun: a place where people can play

import UIKit

enum CardsAndDeclarations {
    case cA, c7, c8, c9, c10, cJ, cQ, cK, kTierce, kQuarte, kQuint, k100, k150, k200, kBelote
    case last10 // 10 points for the last hand taken (optional as it is not set as requirement in homework)
    case kCarreAces // 100 (x2) only on noTrump Game (optional as it is not set as requirement in homework)
}

enum BeloteGameType{
    case allTrump, noTrump
}

func getPoints(game: BeloteGameType, cards: [CardsAndDeclarations] ) -> Int {
    var sum = 0
    
    for item in cards {
        switch (game, item) {
        case (_, .cA):
            sum += 11
        case (_, .c10):
            sum += 10
        case (_, .cK):
            sum += 4
        case (_, .cQ):
            sum += 3
        case (.allTrump, .cJ):
            sum += 20
        case (.noTrump, .cJ):
            sum += 2
        case (.allTrump, .c9):
            sum += 14
        case (.allTrump, .kTierce):
            sum += 20
        case (.allTrump, .kQuarte):
            sum += 50
        case (.allTrump, .kQuint), (.allTrump, .k100), (_, .kCarreAces):
            sum += 100
        case (.allTrump, .k150):
            sum += 150
        case (.allTrump, .k200):
            sum += 200
        case (_, .last10):
            sum += 10
        default:
            break
        }
    }
    
    if game == .noTrump {
        sum *= 2
    }
    
    return sum
}

func getWinner(game: BeloteGameType, team1: [CardsAndDeclarations], team2: [CardsAndDeclarations]) -> Int {
    let team1Points = getPoints(game: game, cards: team1)
    let team2Points = getPoints(game: game, cards: team2)
    
    if team1Points > team2Points {
        return 1
    }
    else if team2Points > team1Points{
        return 2
    }
    else {
        return 0
    }
}

print(getPoints(game: .allTrump, cards: [.cA, .c10, .c8, .c7, .cJ, .cQ, .cK, .cJ]))
print(getPoints(game: .noTrump, cards: [.cA, .c10, .c8, .c7, .cJ, .cQ, .cK, .cJ]))
print(getWinner(game: .allTrump, team1: [.cA, .cA, .c10, .c8, .c7, .k100], team2: [.cJ, .cJ, .c9, .c8, .c7, .c10, .cJ, .k200]))
