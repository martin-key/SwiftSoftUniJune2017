//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"





class Person {
    var name: String!
    var age: Int!
    var height: Int!
    var weight: Float!
    var pID: String!
    
    init(name: String, age: Int, height: Int, weight: Float, pID: String) {
        self.name = name
        self.age = age
        self.height = height
        self.weight = weight
        self.pID = pID
    }
    
    func bmi() -> Float {
        let heightInM = Float(height) / 100
        return weight/(heightInM * heightInM)
    }
}


class Student: Person {
    var marks: [Int]!
    init(name: String, age: Int, height: Int, weight: Float, pID: String, marks: [Int]) {
        super.init(name: name, age: age, height: height, weight: weight, pID: pID)
        self.marks = marks
    }
    
    func averageMark() -> Float {
        var sum = 0
        for mark in self.marks {
            sum += mark
        }
        return Float(sum) / Float(marks.count)
    }
}


func compareStudents(student1: Student, student2: Student) -> Student {
    if student1.averageMark() < student2.averageMark() {
        return student2
    }
    
    return student1
}


let person = Person(name: "John", age: 21, height: 178, weight: 82, pID: "1283718523")
print(person.bmi())

let student1 = Student(name: "Mark", age: 17, height: 180, weight: 72, pID: "2537392761", marks: [6,6,6,4,5,2])
let student2 = Student(name: "Michel", age: 17, height: 169, weight: 68, pID: "251623678", marks: [6,6,6,6,3,3])

let betterStudent = compareStudents(student1: student1, student2: student2)
print(betterStudent.name)
