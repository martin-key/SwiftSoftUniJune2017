//: Playground - noun: a place where people can play

import UIKit

// First class
class MyFirstClass {
    var optionalProperty: String?
    var nonOptionalProperty: String!
    
    convenience init(nonOptionalProperty: String!, optionalProperty: String?) {
        self.init(nonOptionalProperty: nonOptionalProperty)
        
    }
    
    convenience init(nonOptionalProperty: String!) {
        self.init()
        self.nonOptionalProperty = nonOptionalProperty
    }
    
    init(){
        
    }
    
    func compareClassProperties() -> Bool {
        if self.optionalProperty == self.nonOptionalProperty {
            return true
        }
        else {
            return false
        }
    }
}





// ATM and Human task


class ATM {
    var availableMoney: Float
    
    init(availableMoney: Float) {
        self.availableMoney = availableMoney
    }
    
    func canWithdraw(amount: Float, user: Human) -> Bool{
        if user.bankAccountBalance < amount {
            print("Not enough funds")
            return false
        }
        else if self.availableMoney < amount {
            print("Not enough money available in ATM")
            return false
        }
        else {
            return true
        }
    }
}


class Human {
    let name: String!
    var bankAccountBalance: Float
    var cashMoney: Float
    
    init(name: String, bankAccountBalance: Float, cashMoney: Float) {
        self.name = name
        self.bankAccountBalance = bankAccountBalance
        self.cashMoney = cashMoney
    }
    
    func withdraw(amount: Float, atm: ATM) {
        if atm.canWithdraw(amount: amount, user: self) {
            self.cashMoney += amount
            self.bankAccountBalance -= amount
            atm.availableMoney -= amount
        }
        else {
            print("Cannot withdraw 😞☠️👻")
        }
    }
}


//let myATM = ATM(availableMoney: 1200)
//let aHoooman = Human(name: "My Hooman", bankAccountBalance: 2000, cashMoney: 0)
//print(aHoooman.cashMoney, myATM.availableMoney)
//
//aHoooman.withdraw(amount: 400, atm: myATM)
//print(aHoooman.cashMoney, myATM.availableMoney)
//
//
//let human2 = Human(name: "Human 2", bankAccountBalance: 120, cashMoney: 30)
//human2.withdraw(amount: 100, atm: myATM)
//print(human2.cashMoney, myATM.availableMoney)
//
//
//let human3 = Human(name: "Human 3", bankAccountBalance: 500, cashMoney: 10)
//human3.withdraw(amount: 400, atm: myATM)
//print(human3.cashMoney, myATM.availableMoney)



// Access

class AClass {
    var var1: String!
    private var var2: String?
    private (set) var var3: String?
    
    init() {
        var1 = "123"
    }
}

let instance = AClass()
//print(instance.var1)
//print(instance.var2)

// Getters / Setters


class BClass {
    
    var _variable1: String?
    var variable1: String! {
        get {
            if _variable1 == nil {
                _variable1 = "Some value"
            }
            return _variable1!
        }
        set {
            print("Set variable 1 to \(newValue)")
            _variable1 = newValue
        }
    }
    
    var valueObservedVariable: String! {
        willSet {
            print(newValue, self.valueObservedVariable)
        }
        
        didSet {
            print(oldValue, self.valueObservedVariable)
        }
    }
    
    init() {
        self.valueObservedVariable = "123"
    }
}

let instanceB = BClass()
//instanceB.variable1 = "myString"
//instanceB.valueObservedVariable = "My String"


// Lazy

class CClass {
    let aConst = "myConst"
    
    lazy var myLazyVariable: String! = {
        print("myLazyVariable initialized")
        return "Asdf"
    }()
    
    init(){
        
    }
}

//let instanceC = CClass()
//print(instanceC.aConst)
////print(instanceC.myLazyVariable)
//instanceC.myLazyVariable = "Very lazy variable"
//print(instanceC.myLazyVariable)


// Static

class DClass {
    class var helloWorldString: String {
        return "Hello World"
    }
    
    static var classString: String! = "A String"
    static let classLetString: String! = "Something"
    
    class func printHelloWorld(){
        print("Hello world")
    }
}

//DClass.printHelloWorld()
//DClass.classString = "Some other string"
//print(DClass.classString)



// Singleton
class SingletonClass {
    
    static let instance: SingletonClass = SingletonClass()
    
    var var1: String?
    var var2: String?
    var var3: Int = 0
    
    func myFunc() {
        // прави нещо
    }
    
    init() {
    }
}


//SingletonClass.instance.var1 = "A value for var 1"
//print(SingletonClass.instance.var1)
//print(SingletonClass.instance.var3)


// Cups (Struct vs Class)

struct CupStruct {
    var fill: Int // 0 - 100%
}

class CupClass {
    var fill: Int // 0 - 100%
    
    init(initialFill: Int) {
        self.fill = initialFill
    }
}


var cup1Struct = CupStruct(fill: 20)
var cup2Struct = cup1Struct


var cup1Class = CupClass(initialFill: 20)
var cup2Class = cup1Class

cup1Struct.fill = 100
cup1Class.fill = 100
//
//print("cup1structFill:", cup1Struct.fill)
//print("cup2structFill:", cup2Struct.fill)
//print("cup1classFill:", cup1Class.fill)
//print("cup2classFill:", cup2Class.fill)

// Inheritance

class Vehicle {
    let regNumber: String!
    let engine: Float!
    var hps: Float!
    let VIN: String!
    init(regNumber: String, engine: Float, hps:Float, VIN:String) {
        self.regNumber = regNumber
        self.engine = engine
        self.hps = hps
        self.VIN = VIN
    }
}

class Car: Vehicle {
    let numberOfSeats: Int
    init(regNumber: String, engine: Float, hps:Float, VIN:String, numberOfSeats: Int)
    {
        self.numberOfSeats = numberOfSeats
        super.init(regNumber: regNumber, engine: engine, hps: hps, VIN: VIN)
    }
}

class Motorcycle: Vehicle {
    var maxSpeed: Float
    
    init(regNumber: String, engine: Float, hps: Float, VIN: String, maxSpeed: Float) {
        self.maxSpeed = maxSpeed
        super.init(regNumber: regNumber, engine: engine, hps: hps, VIN: VIN)
    }
}

class Tricycle: Motorcycle {
    
}

class Truck: Vehicle {
    let maxLoad: Int
    init(regNumber: String, engine: Float, hps:Float, VIN:String, maxLoad: Int)
    {
        self.maxLoad = maxLoad
        super.init(regNumber: regNumber, engine: engine, hps: hps, VIN: VIN)
    }
}

class LongVehicle: Truck {
    
}

enum SpecialVehicleType {
    case ambulance, police, firetruck
}

class SpecialVehicle: Vehicle {
    let type: SpecialVehicleType!
    init(regNumber: String, engine: Float, hps: Float, VIN: String, type: SpecialVehicleType) {
        self.type = type
        super.init(regNumber: regNumber, engine: engine, hps: hps, VIN: VIN)
    }
}


let ambulance = SpecialVehicle(regNumber: "A 3333 HA", engine: 3.0, hps: 190, VIN: "asnwd29183hbh", type: .ambulance)
let aTricycle = Tricycle(regNumber: "CA 1928 HH", engine: 1.2, hps: 90, VIN: "iauwbidba9817", maxSpeed: 190)

// Polimorphism


func printRegistrationNumber(for vehicle: Vehicle){
    switch vehicle{
    case is SpecialVehicle:
        print("Special vehicle")
    case is Motorcycle:
        print("Motorcycle")
    default:
        break
    }
    print(vehicle.regNumber)
}

printRegistrationNumber(for: ambulance)
printRegistrationNumber(for: aTricycle)


